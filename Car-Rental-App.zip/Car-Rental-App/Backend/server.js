/* Car Rental App - Server & Payment Routes with Stripe */

require('dotenv').config(); // Load environment variables
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Database Connection
if (!process.env.MONGO_URI) {
    console.error("Error: MONGO_URI is not defined in the .env file");
    process.exit(1);
}

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB Connected'))
  .catch(err => {
      console.error("MongoDB Connection Error:", err);
      process.exit(1);
  });

// Routes
const authRoutes = require('./routes/authRoutes');
const rideRoutes = require('./routes/rideRoutes');
const paymentRoutes = require('./routes/paymentRoutes');

app.use('/api/auth', authRoutes);
app.use('/api/rides', rideRoutes);
app.use('/api/payments', paymentRoutes);

app.get('/', (req, res) => {
    res.send('Car Rental App Backend Running');
});

// Start the server
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});

// Ensure environment variables are properly loaded
console.log("Environment Variables Loaded:");
console.log("PORT:", process.env.PORT);
console.log("MONGO_URI:", process.env.MONGO_URI ? "[PROTECTED]" : "NOT SET");
console.log("STRIPE_SECRET_KEY:", process.env.STRIPE_SECRET_KEY ? "[PROTECTED]" : "NOT SET");
console.log("STRIPE_PUBLIC_KEY:", process.env.STRIPE_PUBLIC_KEY ? "[PROTECTED]" : "NOT SET");
console.log("GOOGLE_MAPS_API_KEY:", process.env.GOOGLE_MAPS_API_KEY ? "[PROTECTED]" : "NOT SET");
