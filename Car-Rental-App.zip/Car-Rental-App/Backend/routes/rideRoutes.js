const express = require('express');
const router = express.Router();

// Example route for rides
router.get('/test', (req, res) => {
    res.send("Ride routes working");
});

module.exports = router;
